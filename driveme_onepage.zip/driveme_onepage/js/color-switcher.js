jQuery(document).ready(function($) {
	
	
	 // picker buttton
	jQuery(".picker_close").click(function(){
		jQuery("#choose_color").toggleClass("position");
	});
		   
	
 
  jQuery("#blue-1" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/blue-1.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });
  
  jQuery("#blue-2" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/blue-2.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });  
  
  jQuery("#cumin" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/cumin.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });
  
  jQuery("#gold" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/gold.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });
  
  jQuery("#gray" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/gray.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });  
  
  jQuery("#green-1" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/green-1.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });  
  
  jQuery("#green-2" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/green-2.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });  
  
  jQuery("#orange-1" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/orange-1.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });  
  
  jQuery("#orange-2" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/orange-2.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });  
  
  jQuery("#pink" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/pink.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });  
  
  jQuery("#purple-1" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/purple-1.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });  
  
  jQuery("#purple-2" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/purple-2.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });  
  
  jQuery("#red-1" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/red-1.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });  
  
  jQuery("#red-2" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/red-2.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });  
  
  jQuery("#yellow-1" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/yellow-1.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });
  
  jQuery("#yellow-2" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/yellow-2.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
  });
		  
  jQuery("#default" ).click(function(){
	  jQuery("#color" ).attr("href", "css/color/default.css");
	  jQuery(".logo img" ).attr("src", "images/logo.png");
	  return false;
	});
});